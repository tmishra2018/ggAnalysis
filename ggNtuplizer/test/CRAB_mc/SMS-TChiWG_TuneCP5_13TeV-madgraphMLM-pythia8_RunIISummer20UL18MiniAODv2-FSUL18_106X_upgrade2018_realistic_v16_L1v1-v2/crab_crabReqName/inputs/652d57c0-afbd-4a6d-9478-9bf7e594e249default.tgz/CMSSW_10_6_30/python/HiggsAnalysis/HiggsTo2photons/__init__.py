#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/HiggsAnalysis/HiggsTo2photons/',1)[0])+'/cfipython/slc7_amd64_gcc820/HiggsAnalysis/HiggsTo2photons')
