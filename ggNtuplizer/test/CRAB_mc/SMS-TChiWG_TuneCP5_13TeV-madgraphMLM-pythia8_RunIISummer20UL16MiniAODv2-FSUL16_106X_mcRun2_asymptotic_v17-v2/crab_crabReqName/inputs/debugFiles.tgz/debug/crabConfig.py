from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = False
config.General.workArea = 'CRAB_mc/SMS-TChiWG_TuneCP5_13TeV-madgraphMLM-pythia8_RunIISummer20UL16MiniAODv2-FSUL16_106X_mcRun2_asymptotic_v17-v2'
config.General.requestName = 'crabReqName'
config.section_('JobType')
config.JobType.psetName = 'run_mc2016preVFP_106X.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/SMS-TChiWG_TuneCP5_13TeV-madgraphMLM-pythia8/RunIISummer20UL16MiniAODv2-FSUL16_106X_mcRun2_asymptotic_v17-v2/MINIAODSIM'
config.Data.totalUnits = -1
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/trmishra/SMS-TChiWG_TuneCP5_13TeV-madgraphMLM-pythia8_RunIISummer20UL16MiniAODv2-FSUL16_106X_mcRun2_asymptotic_v17-v2'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_US_FNALLPC'
config.section_('User')
config.section_('Debug')
